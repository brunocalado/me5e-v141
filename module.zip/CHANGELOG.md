# 1.1.2
- backgrounds converted
- species converted
- backgrounds automated
- compendium folder organization
- added dnd5e.config.toolProficiencies['ssna'] = 'Starship Systems (Navigation)'; and dnd5e.config.toolProficiencies['ches'] = "Chemist's Supplies";
- classes support subclass
- adept and engineer add spell dc